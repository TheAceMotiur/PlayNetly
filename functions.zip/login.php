<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>
<body>
    <h1>Login Page</h1>
    <a href="https://onenetly.com/api/oauth?app_id=8746867909080">
        <button>Log in With OneNetly</button>
    </a>

    <a href="https://onenetly.com/api/oauth?app_id=149697232994196">
        <button>Log in With OneNetly 2</button>
    </a>
</body>
</html>