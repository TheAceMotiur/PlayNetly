    <footer class="bg-gray-800 text-white p-4 text-center">
        &copy; 2024 OneNetly, All rights reserved.
    </footer>
</body>
</html>